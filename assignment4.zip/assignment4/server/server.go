package main

import (
	pb "assignment4"
	"context"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"net"
)

type Server struct {
	pb.UnimplementedUserServiceServer
	users []*pb.User
}

func (s *Server) AddUser(ctx context.Context, user *pb.User) (*pb.UserId, error) {
	user.Id = int32(len(s.users) + 1)
	s.users = append(s.users, user)
	return &pb.UserId{Id: user.Id}, nil
}

func (s *Server) GetUser(ctx context.Context, userId *pb.UserId) (*pb.User, error) {
	if int(userId.Id)-1 < len(s.users) && userId.Id > 0 {
		return s.users[userId.Id-1], nil
	}
	return nil, fmt.Errorf("user with ID %d not found", userId.Id)
}

func (s *Server) ListUsers(ctx context.Context, empty *pb.Empty) (*pb.UserList, error) {
	return &pb.UserList{Users: s.users}, nil
}

func main() {
	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		panic(err)
	}
	s := grpc.NewServer()
	pb.RegisterUserServiceServer(s, &Server{})
	reflection.Register(s)
	if err := s.Serve(lis); err != nil {
		panic(err)
	}
}
