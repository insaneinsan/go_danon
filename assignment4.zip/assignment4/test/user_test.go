package main

import (
	pb "awesome-4"
	"context"
	"fmt"
	"reflect"
	"testing"
)

type Server struct {
	pb.UnimplementedUserServiceServer
	users []*pb.User
}

func (s *Server) AddUser(ctx context.Context, user *pb.User) (*pb.UserId, error) {
	user.Id = int32(len(s.users) + 1)
	s.users = append(s.users, user)
	return &pb.UserId{Id: user.Id}, nil
}

func (s *Server) GetUser(ctx context.Context, userId *pb.UserId) (*pb.User, error) {
	if int(userId.Id)-1 < len(s.users) && userId.Id > 0 {
		return s.users[userId.Id-1], nil
	}
	return nil, fmt.Errorf("user with ID %d not found", userId.Id)
}

func (s *Server) ListUsers(ctx context.Context, empty *pb.Empty) (*pb.UserList, error) {
	return &pb.UserList{Users: s.users}, nil
}

func TestAddUser(t *testing.T) {
	s := &Server{}
	user := &pb.User{Name: "Dana", Email: "dana@gmail.com"}
	userId, err := s.AddUser(context.Background(), user)
	if err != nil {
		t.Fatalf("AddUser() error = %v, wantErr %v", err, false)
	}
	if userId.Id != 1 {
		t.Errorf("Expected user ID 1, got %d", userId.Id)
	}
	if len(s.users) != 1 {
		t.Errorf("Expected 1 user in the slice, got %d", len(s.users))
	}
}

func TestGetUser(t *testing.T) {
	s := &Server{}
	user := &pb.User{Name: "Dana", Email: "dana@gmail.com"}
	s.AddUser(context.Background(), user)
	tests := []struct {
		name    string
		userId  *pb.UserId
		want    *pb.User
		wantErr bool
	}{
		{"Valid ID", &pb.UserId{Id: 1}, user, false},
		{"Invalid ID", &pb.UserId{Id: 99}, nil, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := s.GetUser(context.Background(), tt.userId)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetUser() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("GetUser() got = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestListUsers(t *testing.T) {
	s := &Server{}
	users := []*pb.User{
		{Name: "Dana", Email: "dana@gmail.com"},
		{Name: "John Doe", Email: "john.doe@example.com"},
	}
	for _, user := range users {
		s.AddUser(context.Background(), user)
	}
	want := &pb.UserList{Users: users}
	got, err := s.ListUsers(context.Background(), &pb.Empty{})
	if err != nil {
		t.Fatalf("ListUsers() error = %v, wantErr %v", err, false)
	}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("ListUsers() got = %v, want %v", got, want)
	}
}
