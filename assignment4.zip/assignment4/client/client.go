package main

import (
	"context"
	"fmt"
	"google.golang.org/grpc"
	"log"
	"time"

	pb "assignment4"
)

func main() {
	conn, err := grpc.Dial("localhost:50051", grpc.WithInsecure(), grpc.WithBlock())
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()
	c := pb.NewUserServiceClient(conn)

	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()

	user := &pb.User{Name: "Dana", Email: "dana@gmail.com"}
	userId, err := c.AddUser(ctx, user)
	if err != nil {
		log.Fatalf("could not add user: %v", err)
	}
	fmt.Printf("Added user ID: %d\n", userId.Id)

	retrievedUser, err := c.GetUser(ctx, &pb.UserId{Id: userId.Id})
	if err != nil {
		log.Fatalf("could not retrieve user: %v", err)
	}
	fmt.Printf("Retrieved User: %v\n", retrievedUser)

	users, err := c.ListUsers(ctx, &pb.Empty{})
	if err != nil {
		log.Fatalf("could not list users: %v", err)
	}
	fmt.Println("List of Users:")
	for _, u := range users.Users {
		fmt.Printf("User: %v\n", u)
	}
}
